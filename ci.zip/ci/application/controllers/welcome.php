<?php

class Welcome extends CI_Controller {

	
	function index()
	{
		$this->load->view('user_logged_in');
	}
}

