<!DOCTYPE html>

<html lang="en">
<head>
	 
	<title>Error</title>
</head>
<body>
	<h2>You entered the wrong credentials!</h2>
     <p>First sign up and then log in.</p>
	<h4><?php echo anchor('login/logout', 'Back'); ?></h4>
</body>
</html>	