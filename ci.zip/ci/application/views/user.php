<?php


$dbConn = mysqli_connect ('localhost', 'root', '');
mysqli_select_db($dbConn,'membership');


$result = mysqli_query($dbConn,"SELECT * FROM membership")
;

echo "<table border='1' cellpadding='10'>";
echo "<tr>
<th><font color='Red'>id</font></th>
<th><font color='Red'>Username</font></th>
<th><font color='Red'>Email_address</font></th>
<th><font color='Red'>Role</font></th>
<th><font color='Red'>Edit</font></th>
<th><font color='Red'>Delete</font></th>
</tr>";

while($row = mysqli_fetch_array( $result ))
{

echo "<tr>";
echo '<td><b>' . $row['id'] . '</font></b></td>';
echo '<td><b>' . $row['username'] . '</font></b></td>';
echo '<td><b>' . $row['email_address'] . '</font></b></td>';
echo '<td><b>' . $row['role'] . '</font></b></td>';
echo '<td><b><a href="edit?id=' . $row['id'] . '">Edit</a></font></b></td>';
echo '<td><b><a href="delete?id=' . $row['id'] . '">Delete</a></font></b></td>';
echo "</tr>";

}

echo "</table>";

echo anchor('login/logout', 'Logout');
?>
