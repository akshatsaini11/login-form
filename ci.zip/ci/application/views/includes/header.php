<!DOCTYPE html>

<html lang="en">
<head>
	
	<title>Sign Up!</title>
	<link rel="stylesheet" href="<?php echo base_url();?>/css/style.css" type="text/css" media="screen" />
	
</head>
<body>