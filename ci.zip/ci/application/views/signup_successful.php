<!DOCTYPE html>

<html lang="en">
<head>
	 
	<title>untitled</title>
</head>
<body>
	<h2>Congrats!</h2>
     <p>Your account is created!</p>
	<h4><?php echo anchor('login', 'Login Now'); ?></h4>
	
</body>
</html>	