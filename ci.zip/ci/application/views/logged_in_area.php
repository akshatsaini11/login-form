<!DOCTYPE html>

<html lang="en">
<head>
	 
	<title>untitled</title>
</head>
<body>
	<h2>Welcome Admin, <?php echo $this->session->userdata('username'); ?>!</h2>
    <p>This section represents the area that only admins can access.</p>
	<h4><?php echo anchor('login/logout', 'Logout'); ?></h4>
    <h4><?php echo anchor('login/user', 'View User List'); ?></h4>

</body>
</html>	