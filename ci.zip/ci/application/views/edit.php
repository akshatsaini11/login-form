<?php
function valid($id, $username, $email_address,$role, $error)
{
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Edit Records</title>
</head>
<body>
<?php

if ($error != '')
{
echo '<div style="padding:4px; border:1px solid red; color:red;">'.$error.'</div>';
}
?>

<form action="" method="post">
<input type="hidden" name="id" value="<?php echo $id; ?>"/>

<table border="1">
<tr>
<td colspan="2"><b><font color='Red'>Edit Records </font></b></td>
</tr>
<tr>
<td width="179"><b>Username</b></td>
<td><label>
<input type="text" name="username" value="<?php echo $username; ?>" />
</label></td>
</tr>

<tr>
<td width="179"><b>Email Address</b></td>
<td><label>
<input type="text" name="email_address" value="<?php echo $email_address; ?>" />
</label></td>
</tr>

<tr>
<td width="179"><b>Role</b></td>
<td><label>
<input type="text" name="role" value="<?php echo $role; ?>" />
</label></td>
</tr>

<tr align="Right">
<td colspan="2"><label>
<input type="submit" name="submit" value="Edit Records">
</label></td>
</tr>
</table>
</form>
</body>
</html>
<?php
}



if (isset($_POST['submit']))
{

if (is_numeric($_POST['id']))
{
$dbConn = mysqli_connect ('localhost', 'root', '');
mysqli_select_db($dbConn,'membership');
$id = $_POST['id'];
$username = mysqli_real_escape_string($dbConn,$_POST['username']);
$email_address = mysqli_real_escape_string($dbConn,$_POST['email_address']);
$role = mysqli_real_escape_string($dbConn,$_POST['role']);


if ($username == '' || $email_address == '' || $role == '')
{

$error = 'ERROR: Please fill in all required fields!';


valid($id, $username, $email_address,$role, $error);
}
else
{

mysqli_query($dbConn, "UPDATE membership SET username='$username', email_address='$email_address' ,role='$role' WHERE id='$id'")
or die(mysqli_error($dbConn));

header("Location: user");
}
}
else
{

echo 'Error!';
}
}
else

{

if (isset($_GET['id']) && is_numeric($_GET['id']) && $_GET['id'] > 0)
{

$id = $_GET['id'];
$dbConn = mysqli_connect ('localhost', 'root', '');
mysqli_select_db($dbConn,'membership');



$result = mysqli_query($dbConn,"SELECT * FROM membership WHERE id=$id")
or die(mysqli_error());
$row = mysqli_fetch_array($result);

if($row)
{

$username = $row['username'];
$email_address = $row['email_address'];
$role = $row['role'];

valid($id, $username, $email_address,$role,'');
}
else
{
echo "No results!";
}
}
else

{
echo 'Error!';
}
}
?>
