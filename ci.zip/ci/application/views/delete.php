<?php

$dbConn = mysqli_connect ('localhost', 'root', '');
mysqli_select_db($dbConn,'membership');
if (isset($_GET['id']) && is_numeric($_GET['id']))
{
$id = $_GET['id'];

$result = mysqli_query($dbConn, "DELETE FROM membership WHERE id=$id")
or die(mysqli_error());

header("Location: user");
}
else

{
header("Location: user");
}
?>