<!DOCTYPE html>

<html lang="en">
<head>
	 
	<title>untitled</title>
</head>
<body>
	<h2>Welcome User!</h2>
     <p>This section represents the area that only users can access.</p>
	<h4><?php echo anchor('login/logout', 'Logout'); ?></h4>
	
</body>
</html>	